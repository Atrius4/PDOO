﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorArepas
{
    class ArepaCongelada : Arepa, ICongelable
    {
        private int diasMaximosCongelado;

        public ArepaCongelada() : base()
         {
            diasMaximosCongelado = 0;
         }

        public ArepaCongelada(int numeroMolino, int diasCaducidad, int diasMaximosCongelado) : base(numeroMolino, diasCaducidad)
        {

            this.diasMaximosCongelado = diasMaximosCongelado;
        }

        public int DiasMaximosCongelado 
        {
            get { return diasMaximosCongelado; }
            set { diasMaximosCongelado = value; }
        }

        public string InfoCongelacion()
        {
            string resultado = "Dias Máximos de congelacion: " + diasMaximosCongelado + Environment.NewLine;
            return resultado;
        }

        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue congelada. " + Environment.NewLine + "La masa salió del molino " + numeroMolino + Environment.NewLine + "Tiene " + diasCaducidad + " dias de caducidad" + Environment.NewLine + InfoCongelacion();
            return resultado;
        }
    }
}
