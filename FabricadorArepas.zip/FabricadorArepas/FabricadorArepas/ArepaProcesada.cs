﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorArepas
{
    class ArepaProcesada : Arepa, IAsable, ICongelable
    {
        private int diasMaximoCongelado, tempCoccion;

        public ArepaProcesada() : base ()
        {
            diasMaximoCongelado = 0;
            tempCoccion = 0;
        }

        public ArepaProcesada(int diasMaximoCongelado, int tempCoccion, int numeroMolino, int diasCaducidad) : base(numeroMolino, diasCaducidad)
        {
            this.diasMaximoCongelado = diasMaximoCongelado;
            this.tempCoccion = tempCoccion;
        }
        public int TempCoccion {
            get { return tempCoccion; }
            set { tempCoccion = value; }
        }

        public string InfoCoccion()
        {
            string resultado = "Temperatura de cocción en proceso: " + tempCoccion + Environment.NewLine;
            return resultado;
        }

        public string InfoCongelacion()
        {
            string resultado = "Días máximos de congelación en proceso: " + diasMaximoCongelado + Environment.NewLine;
            return resultado;
        }

        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue Procesada. " + Environment.NewLine + "La masa salió del molino " + numeroMolino + Environment.NewLine + "Tiene " + diasCaducidad + " dias de caducidad" + Environment.NewLine + InfoCoccion() + InfoCongelacion();
            return resultado;
        }
    }
}
