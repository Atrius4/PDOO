﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorArepas
{
    class ArepaAsada : Arepa, IAsable
    {
        private int tempCoccion;

        public ArepaAsada() : base()
        {
            tempCoccion = 0;
        }

        public ArepaAsada(int numeroMolino, int diasCaducidad, int tempCoccion) : base(numeroMolino, diasCaducidad)
        {
            this.tempCoccion = tempCoccion;
        }

        public int TempCoccion {
            get { return tempCoccion; }
            set { tempCoccion = value; }
        }

        public string InfoCoccion()
        {
            string resultado = "Temperatura de cocción: " + tempCoccion + Environment.NewLine;
            return resultado;
        }

        public override string ObtieneInformacion()
        {
            string resultado = "Esta arepa fue Asada. " + Environment.NewLine + "La masa salió del molino " + numeroMolino + Environment.NewLine + "Tiene " + diasCaducidad + " dias de caducidad" + Environment.NewLine + InfoCoccion();
            return resultado;
        }
    }
}
