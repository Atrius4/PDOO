﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorArepas
{
    abstract class Arepa
    {
        protected int numeroMolino, diasCaducidad;


        public Arepa()
        {
            numeroMolino = 0;
            diasCaducidad = 0;
        }

        public Arepa(int numeroMolino, int diasCaducidad)
        {
            this.numeroMolino = numeroMolino;
            this.diasCaducidad = diasCaducidad;

        }

        public int NumeroMolino 
            
            {
            get { return numeroMolino; }
            set { numeroMolino = value; }
            }

        public int DiasCaducidad {
            get { return diasCaducidad; }
            set { diasCaducidad = value; }
        }


        public abstract string ObtieneInformacion();
    }
}
