﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FabricadorArepas
{
    class CreadorArepas
    {
        private int totalAsadas, totalCongeladas, totalProcesadas;
        private Arepa[] misArepas;

        public CreadorArepas()
        {
            totalAsadas = 0;
            totalCongeladas = 0;
            totalProcesadas = 0;

            misArepas = new Arepa[100];
        }

        public int TotalAsadas 
        {
            get { return totalAsadas; }
        }

        public int TotalCongeladas
        {
            get { return totalCongeladas; }
        }

        public int TotalProcesadas 
        {
            get { return totalProcesadas; }
        }

        public void InicializaArepas()
        {
            totalAsadas = 0;
            totalCongeladas = 0;
            totalProcesadas = 0;

            Random aleatorio = new Random(DateTime.Now.Millisecond);

            int tipo = 0; // 0: Congelada, 1: Asada, 2: Procesada
            int datoMolino = 0; // 10 molinos
            int datoDiasCaducidad = 0; //Entre 15 y 30 días
            int datoTemperatura = 0; // entre 60 y 90
            int datoCongelación = 0;// dias entre 20 y 60

            for (int i = 0; i < misArepas.Length; i++)
            {
                tipo = aleatorio.Next(3);
                datoMolino = aleatorio.Next(1, 11);
                datoDiasCaducidad = aleatorio.Next(15, 31);

                switch (tipo)
                {
                    case 0:
                        datoCongelación = aleatorio.Next(20, 61);
                        misArepas[i] = new ArepaCongelada(datoMolino, datoDiasCaducidad, datoCongelación);
                        totalCongeladas++;
                        break;
                    case 1:
                        datoTemperatura = aleatorio.Next(60, 91);
                        misArepas[i] = new ArepaAsada(datoMolino, datoDiasCaducidad, datoTemperatura);
                        break;
                    case 2:
                        datoCongelación = aleatorio.Next(20, 61);
                        datoTemperatura = aleatorio.Next(60, 91);
                        misArepas[i] = new ArepaProcesada(datoCongelación, datoTemperatura, datoMolino, datoDiasCaducidad);
                        break;
                }
            }
        }

        public string ObtieneTotalInfo()
        {
            StringBuilder resultado = new StringBuilder();
            for (int i = 0; i < misArepas.Length; i++)
            {
                resultado.Append("Arepa # " + (i + 1) + Environment.NewLine + misArepas[i].ObtieneInformacion());            }
            return resultado.ToString();
        }
    }
}
